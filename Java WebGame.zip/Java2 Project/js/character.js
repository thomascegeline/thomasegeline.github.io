// ===== character.js =====
class Character {
  constructor(name, stats) {
    this.name = name;
    this.stats = stats;
    this.maxHP = stats.constitution * 10;
    this.currentHP = this.maxHP;
    this.maxMP = stats.intelligence * 5;
    this.currentMP = this.maxMP;
    this.level = 1;
    this.xp = 0;
    this.nextLevelXP = 100;
  }

  isAlive() {
    return this.currentHP > 0;
  }

  attack(target) {
    const dmg = Math.floor(
      this.stats.strength + Math.random() * this.stats.dexterity
    );
    target.currentHP = Math.max(0, target.currentHP - dmg);
    log(`${this.name} attacks ${target.name} for ${dmg} damage!`);
  }
}

class Player extends Character {
  constructor(name, charClass, stats) {
    super(name, stats);
    this.charClass = charClass;
  }

  castSpell(target) {
    const cost = 10;
    if (this.currentMP < cost) {
      log(`${this.name} tried to cast a spell but didn't have enough mana!`);
      return;
    }
    this.currentMP -= cost;
    const dmg = Math.floor(this.stats.intelligence * 2 + Math.random() * 5);
    target.currentHP = Math.max(0, target.currentHP - dmg);
    log(`${this.name} casts a spell for ${dmg} damage! (-${cost} MP)`);
  }

  useAbility(target) {
    const cost = 8;
    if (this.currentMP < cost) {
      log(`${this.name} doesn't have enough mana for a special ability!`);
      return;
    }
    this.currentMP -= cost;
    const dmg = Math.floor(this.stats.strength * 1.5 + Math.random() * 5);
    target.currentHP = Math.max(0, target.currentHP - dmg);
    log(`${this.name} uses a special ability for ${dmg} damage! (-${cost} MP)`);
  }

  gainXP(amount) {
    this.xp += amount;
    let message = `✨ ${this.name} gained ${amount} XP!`;

    while (this.xp >= this.nextLevelXP) {
      this.xp -= this.nextLevelXP;
      this.nextLevelXP += 100;
      const levelMsg = this.levelUp();
      message += `\n${levelMsg}`;
    }

    return message;
  }

  levelUp() {
    this.level++;
    this.stats.strength++;
    this.stats.constitution++;
    this.stats.intelligence++;
    this.stats.dexterity++;
    this.stats.wisdom++;

    this.maxHP = this.stats.constitution * 10;
    this.maxMP = this.stats.intelligence * 5;
    this.currentHP = this.maxHP;
    this.currentMP = this.maxMP;

    return `🆙 ${this.name} leveled up to Level ${this.level}! HP and MP fully restored.`;
  }
}

class Enemy extends Character {
  constructor(name, stats, xpValue) {
    super(name, stats);
    this.xpValue = xpValue;
  }

  takeTurn(target) {
    if (!this.isAlive()) return;
    const dmg = Math.floor(this.stats.strength + Math.random() * 4);
    target.currentHP = Math.max(0, target.currentHP - dmg);
    log(`${this.name} attacks ${target.name} for ${dmg} damage!`);
  }
}
