// ===== script.js =====
let player;
let battle;

function selectClass(className) {
  let stats;
  if (className === "Warrior") {
    stats = { strength: 6, dexterity: 4, constitution: 6, intelligence: 2, wisdom: 3 };
  } else if (className === "Mage") {
    stats = { strength: 2, dexterity: 3, constitution: 3, intelligence: 7, wisdom: 5 };
  } else if (className === "Rogue") {
    stats = { strength: 4, dexterity: 7, constitution: 4, intelligence: 3, wisdom: 3 };
  }

  player = new Player("Hero", className, stats);
  battle = new BattleManager(player);

  document.getElementById("class-select").style.display = "none";
  log(`You have chosen the path of the ${className}!`);
  updateActionButtons();
  battle.startBattle();
}

function attack() {
  battle.playerAction("attack");
}

function useAbility() {
  battle.playerAction("special");
}

function castSpell() {
  battle.playerAction("spell");
}

function updateActionButtons() {
  const spellBtn = document.getElementById("spell-btn");

  // If player is Mage, show spell button; otherwise hide it
  if (player.charClass === "Mage") {
    spellBtn.style.display = "inline-block";
  } else {
    spellBtn.style.display = "none";
  }
}