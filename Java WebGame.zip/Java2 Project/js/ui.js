// ===== ui.js =====
const playerStats = document.getElementById("player-stats");
const enemyStats = document.getElementById("enemy-stats");
const logDiv = document.getElementById("battle-log");

function log(message) {
  const p = document.createElement("p");
  p.textContent = message;
  logDiv.appendChild(p);
  logDiv.scrollTop = logDiv.scrollHeight;
}

function updateStats() {
  const xpPct = Math.round((player.xp / player.nextLevelXP) * 100);
  const hpPct = Math.round((player.currentHP / player.maxHP) * 100);
  const mpPct = Math.round((player.currentMP / player.maxMP) * 100);

  playerStats.innerHTML = `
    <strong>${player.name} (${player.charClass})</strong><br>
    Level: ${player.level}<br>
    XP: ${player.xp} / ${player.nextLevelXP}
    <div class="bar-container"><div class="bar xp-bar" style="width:${xpPct}%"></div></div>
    HP: ${player.currentHP} / ${player.maxHP}
    <div class="bar-container"><div class="bar hp-bar" style="width:${hpPct}%"></div></div>
    MP: ${player.currentMP} / ${player.maxMP}
    <div class="bar-container"><div class="bar mp-bar" style="width:${mpPct}%"></div></div>
  `;

  const eHpPct = Math.round((battle.enemy.currentHP / battle.enemy.maxHP) * 100);
  enemyStats.innerHTML = `
    <strong>${battle.enemy.name}</strong><br>
    HP: ${battle.enemy.currentHP} / ${battle.enemy.maxHP}
    <div class="bar-container"><div class="bar hp-bar" style="width:${eHpPct}%"></div></div>
  `;
}
