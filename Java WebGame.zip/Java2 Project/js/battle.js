// ===== battle.js =====
class BattleManager {
  constructor(player) {
    this.player = player;
    this.enemy = null;
  }

  startBattle() {
    this.enemy = this.generateEnemy();
    log(`⚔️ A wild ${this.enemy.name} appears!`);
    updateStats();
  }

  // Generate enemy based on player level
  generateEnemy() {
    const level = this.player.level;

    // Chance of Orc increases with player level (max 70%)
    const orcChance = Math.min(level * 0.1, 0.7);
    const roll = Math.random();

    if (roll < orcChance) {
      // Create Orc
      const stats = {
        strength: 6 + level,       // stronger with higher level
        dexterity: 4 + Math.floor(level / 2),
        constitution: 6 + level,
        intelligence: 2 + Math.floor(level / 3),
        wisdom: 3 + Math.floor(level / 3)
      };
      return new Enemy("Orc", stats, 100 + level * 10);
    } else {
      // Create Goblin
      const stats = {
        strength: 4 + Math.floor(level / 2),
        dexterity: 3 + Math.floor(level / 3),
        constitution: 4 + Math.floor(level / 2),
        intelligence: 2 + Math.floor(level / 3),
        wisdom: 1 + Math.floor(level / 3)
      };
      return new Enemy("Goblin", stats, 50 + level * 5);
    }
  }

  playerAction(actionType) {
    if (!this.player.isAlive() || !this.enemy.isAlive()) return;

    // Player turn
    if (actionType === "attack") this.player.attack(this.enemy);
    else if (actionType === "spell") this.player.castSpell(this.enemy);
    else if (actionType === "special") this.player.useAbility(this.enemy);

    updateStats();

    if (!this.enemy.isAlive()) {
      log(`💀 ${this.enemy.name} is defeated!`);
      const xpMessage = this.player.gainXP(this.enemy.xpValue);
      log(xpMessage);

      setTimeout(() => this.startBattle(), 2500);
      return;
    }

    // Enemy turn
    setTimeout(() => {
      this.enemy.takeTurn(this.player);
      updateStats();

      if (!this.player.isAlive()) {
        log(`☠️ ${this.player.name} has fallen! Game Over.`);
      }
    }, 1000);
  }
}
