﻿using LyricSearch.Data.Data;
using LyricSearch.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace LyricSearch.Data.Seed
{
    public static class DataSeeder
    {
        public static void Seed(AppDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Songs.Any())
                return;

            var artistNames = new[]
            {
                "The Midnight Echo", "Neon Horizon", "Static Dreams", "Silver Waves",
                "Blue Satellite", "Echo District", "Paper Skies", "Lost Frequency",
                "Digital Heart", "Velvet Storm"
            };

            var albumTitles = new[]
            {
                "Night Signals", "City Glow", "Broken Radio", "Afterlight",
                "Neon Memories", "Midnight Drive", "Fading Static"
            };

            var words = new[]
            {
                "night", "love", "echo", "dream", "light", "shadow",
                "rain", "fire", "sky", "heart", "lost", "wave"
            };

            var artists = artistNames
                .Select(name => new Artist { Name = name })
                .ToList();

            context.Artists.AddRange(artists);

            var albums = albumTitles
                .Select((title, index) => new Album
                {
                    Title = title,
                    Artist = artists[index % artists.Count]
                })
                .ToList();

            context.Albums.AddRange(albums);

            var songs = new List<Song>();

            for (int i = 1; i <= 150; i++)
            {
                var artist = artists[i % artists.Count];
                var album = albums[i % albums.Count];

                songs.Add(new Song
                {
                    Title = $"{words[i % words.Length]} Drift",
                    Lyrics = $"The {words[i % words.Length]} fades into {words[(i + 3) % words.Length]} as time moves slowly through the silence.",
                    Artist = artist,
                    Album = album
                });
            }

            context.Songs.AddRange(songs);

            context.SaveChanges();
        }
    }
}