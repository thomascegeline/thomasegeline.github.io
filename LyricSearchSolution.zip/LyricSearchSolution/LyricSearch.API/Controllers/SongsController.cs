﻿using LyricSearch.Data.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LyricSearch.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SongsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public SongsController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("all")]
        public IActionResult GetAll()
        {
            var songs = _context.Songs.ToList();
            return Ok(songs);
        }

        [HttpGet("search")]
        public async Task<IActionResult> Search(string query)
        {
            var results = await _context.Songs
                .Include(s => s.Artist)
                .Include(s => s.Album)
                .Where(s => s.Lyrics != null && s.Lyrics.ToLower().Contains(query.ToLower()))
                .Select(s => new
                {
                    s.Title,
                    s.Lyrics,
                    Artist = s.Artist.Name,
                    Album = s.Album.Title
                })
                .ToListAsync();

            return Ok(results);
        }
    }
}
