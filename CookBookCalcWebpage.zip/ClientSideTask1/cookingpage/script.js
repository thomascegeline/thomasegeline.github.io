/* Thomas Egeline Date: 2025-10-19 */

/* ===== Global Variables ===== */
/* All tips from https://www.seriouseats.com/essential-kitchen-tricks-and-tips */
const cookingTips = [
    "Peel ginger with a spoon instead of a knife — it follows the contours and cuts down on waste.",
    "Freeze liquids in usable portions (e.g., wine in ice-cube trays) so you don’t open a full bottle every time.", 
    "Use a scale when baking — volumetric cups can vary greatly and lead to inconsistent results.",              
    "Store greens and herbs in a damp paper-towel inside a zipper-lock bag to extend freshness.",                
    "Don’t be afraid of salt, but don’t forget the acid — seasoning and brightening both matter.",               
    "Use the empty half of an eggshell to scoop out tiny shell bits — it acts like a magnet for shell pieces."    
];

/* ===== Functions ===== */

// Function 1: Display a random cooking tip
function showCookingTip() {
    const tipOutput = document.getElementById("tipOutput");
    const randomIndex = Math.floor(Math.random() * cookingTips.length);
    tipOutput.textContent = cookingTips[randomIndex];
}

// Function 2: Add a new recipe to the list
function addRecipe() {
    const input = document.getElementById("newRecipe");
    const recipeList = document.getElementById("recipeList");

    if (input.value.trim() !== "") {
        const li = document.createElement("li");
        li.textContent = input.value.trim();
        recipeList.appendChild(li);
        input.value = "";
    } else {
        alert("Please enter a recipe name!");
    }
}

// Function 3: Calculate scaled ingredient amount
function calculateIngredients(event) {
    event.preventDefault(); // Prevent page reload

    const servings = parseFloat(document.getElementById("servings").value);
    const desired = parseFloat(document.getElementById("desired").value);
    const ingredient = parseFloat(document.getElementById("ingredient").value);
    const result = document.getElementById("calcResult");

    if (servings > 0 && desired > 0 && ingredient > 0) {
        const newAmount = (desired / servings) * ingredient;
        result.textContent = `You need ${newAmount.toFixed(2)} cups.`;
    } else {
        result.textContent = "Please enter valid numbers.";
    }
}

// Function 4: Highlight recipes when hovered
function highlightRecipe(event) {
    event.target.style.color = "#ff7b00";
}

function unhighlightRecipe(event) {
    event.target.style.color = "#333";
}

/* ===== Event Listeners ===== */
document.addEventListener("DOMContentLoaded", () => {
    const tipButton = document.getElementById("tipButton");
    const addRecipeBtn = document.getElementById("addRecipeBtn");
    const calcForm = document.getElementById("calcForm");
    const recipeList = document.getElementById("recipeList");

    if (tipButton) tipButton.addEventListener("click", showCookingTip);
    if (addRecipeBtn) addRecipeBtn.addEventListener("click", addRecipe);
    if (calcForm) calcForm.addEventListener("submit", calculateIngredients);
    if (recipeList) {
        recipeList.addEventListener("mouseover", highlightRecipe);
        recipeList.addEventListener("mouseout", unhighlightRecipe);
    }
});
